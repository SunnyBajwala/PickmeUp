// Grabbing the DOM elements for easier access
const jokeEl = document.getElementById("jokeLoad");
const getJokeBtn = document.getElementById("get_joke");
const saveJokeBtn = document.getElementById("save-joke");
const modeToggle = document.getElementById("mode-toggle"); // Light/Dark mode toggle button
const modeLabel = document.getElementById("mode-label"); // Label that shows which mode is active

// Function to get the selected joke category from the dropdown
function getSelectedJokeCategory() {
  const jokeCategorySelect = document.getElementById("joke-category");
  return jokeCategorySelect.value.toLowerCase(); // Converts the category to lowercase for consistency
}

// Event listener for fetching a new joke when the button is clicked
getJokeBtn.addEventListener("click", async () => {
  const category = getSelectedJokeCategory();

  // If no category is selected, show a message
  if (!category) {
    jokeEl.innerHTML = "Please select a category!";
    return;
  }

  // Set the appropriate API URL based on selected category
  const url =
    category === "general"
      ? "https://official-joke-api.appspot.com/jokes/general/random"
      : `https://official-joke-api.appspot.com/jokes/${category}/random`;

  jokeEl.innerHTML = "Loading..."; // Show loading text while fetching the joke
  try {
    // Fetch the joke from the API
    const res = await fetch(url);
    const data = await res.json();
    if (data.length > 0) {
      const joke = data[0]; // Get the first joke from the response
      jokeEl.innerHTML = `${joke.setup} <br> ${joke.punchline}`; // Display the joke on the page
    } else {
      jokeEl.innerHTML = "No jokes found!"; // If no joke is found
    }
  } catch (error) {
    // Handle errors like failed network requests
    jokeEl.innerHTML = "Error fetching joke. Try again!";
    console.error(error);
  }
});

// Event listener for saving the current joke
saveJokeBtn.addEventListener("click", () => {
  const currentJoke = jokeEl.innerHTML;

  // If no joke is displayed or there's an error message, don't save it
  if (!currentJoke || currentJoke.includes("Please select a category")) {
    alert("No joke to save!");
    return;
  }

  // Retrieve saved jokes from localStorage, or create an empty array if none exist
  const savedJokes = JSON.parse(localStorage.getItem("jokes")) || [];
  savedJokes.push(currentJoke); // Add the current joke to the saved jokes array
  localStorage.setItem("jokes", JSON.stringify(savedJokes)); // Save it back to localStorage
  alert("Joke saved!"); // Notify the user that the joke is saved
});

// Event listener for opening the saved jokes modal
document.getElementById("view-saved-jokes").addEventListener("click", () => {
  const savedJokes = JSON.parse(localStorage.getItem("jokes")) || [];

  // Clear any existing jokes in the list
  const savedJokesList = document.getElementById("saved-jokes-list");
  savedJokesList.innerHTML = "";

  // If no saved jokes, show a message
  if (savedJokes.length === 0) {
    savedJokesList.innerHTML = "<li>No saved jokes yet!</li>";
  } else {
    // Otherwise, display the saved jokes
    savedJokes.forEach((joke) => {
      const li = document.createElement("li");
      li.innerHTML = joke;
      savedJokesList.appendChild(li); // Add each saved joke to the modal list
    });
  }

  // Show the modal with the saved jokes
  const savedJokesModal = document.getElementById("saved-jokes-modal");
  savedJokesModal.style.display = "block";
});

// Close the saved jokes modal
document.querySelector(".close-modal").addEventListener("click", () => {
  document.getElementById("saved-jokes-modal").style.display = "none";
});

// Close the modal if the user clicks outside of it
window.addEventListener("click", (event) => {
  const savedJokesModal = document.getElementById("saved-jokes-modal");
  if (event.target === savedJokesModal) {
    savedJokesModal.style.display = "none";
  }
});

// Event listener for the light/dark mode toggle
modeToggle.addEventListener("change", () => {
  document.body.classList.toggle("dark-mode"); // Toggle the dark mode class on the body element

  // Change the text of the mode label based on the current state
  if (document.body.classList.contains("dark-mode")) {
    modeLabel.textContent = "Light Mode";
    localStorage.setItem("theme", "dark"); // Save the preference in localStorage
  } else {
    modeLabel.textContent = "Dark Mode";
    localStorage.setItem("theme", "light"); // Save the preference in localStorage
  }
});

// Apply the saved theme preference on page load (if any)
window.addEventListener("DOMContentLoaded", () => {
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "dark") {
    document.body.classList.add("dark-mode");
    modeToggle.checked = true; // Check the toggle if dark mode was saved
    modeLabel.textContent = "Light Mode";
  }
});
